﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SunshineSketch
{
    /// <summary>
    /// Interaction logic for SS_Settings.xaml
    /// </summary>
    public partial class SS_Settings : Window
    {
        public SS_Settings()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            Properties.Settings.Default.Save();
            Close();
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            Properties.Settings.Default.Reset();
            Close();
        }
    }
}
