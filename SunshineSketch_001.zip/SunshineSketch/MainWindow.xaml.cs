﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.ComponentModel;
using System.Windows.Ink;
using System.Globalization;

namespace SunshineSketch
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // public GUID
        Guid wd = new Guid("12345678-9012-3456-7890-123456789012");
        Guid ht = new Guid("12345678-9012-3456-7890-123456789013");
        Guid bg = new Guid("12345678-9012-3456-7890-123456789014");

        public MainWindow()
        {
            InitializeComponent();
            SketchSurface.AddHandler(InkCanvas.MouseRightButtonDownEvent, new MouseButtonEventHandler(UseRightTool), true);
            SketchSurface_mid.AddHandler(InkCanvas.MouseRightButtonDownEvent, new MouseButtonEventHandler(UseRightTool), true);
            SketchSurface.DefaultDrawingAttributes.Width = 3;
            SketchSurface.DefaultDrawingAttributes.Height = 3;
        }

        

        void MainWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            string messageBoxText = "Are you sure you wish to exit? All unsaved changes will be lost!";
            string caption = "Exit Sunshine Studio";
            MessageBoxButton button = MessageBoxButton.YesNo;
            MessageBoxImage icon = MessageBoxImage.Warning;
            MessageBoxResult result = MessageBox.Show(messageBoxText, caption, button, icon);
            switch (result)
            {
                case MessageBoxResult.Yes:
                    Application curApp = Application.Current;
                    curApp.Shutdown();
                    break;
                case MessageBoxResult.No:
                    e.Cancel = true;
                    break;
            }

        }

        private void File_Exit(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void BG_Button_Click(object sender, RoutedEventArgs e)
        {
            // Configure open file dialog box
            Microsoft.Win32.OpenFileDialog CanBG = new Microsoft.Win32.OpenFileDialog();
            CanBG.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyPictures);
            CanBG.FileName = "Background"; // Default file name
            CanBG.DefaultExt = ".png"; // Default file extension
            CanBG.Filter = "Portable Network Graphics (.png)|*.png"; // Filter files by extension 

            // Show open file dialog box
            Nullable<bool> result = CanBG.ShowDialog();

            // Process open file dialog box results 
            if (result == true)
            {
                // Open document 
                string BG_Image = CanBG.FileName;
           
                Canvas canvas = new Canvas { Width = SketchSurface.ActualWidth, Height = SketchSurface.ActualHeight };
                Image BGimage = new Image
                {
                    Width = SketchSurface.ActualWidth,
                    Height = SketchSurface.ActualHeight,
                    Stretch = Stretch.Fill,
                    Source = new BitmapImage(new Uri(BG_Image))

                };
                SketchSurface.Children.Add(canvas);
                canvas.Children.Add(BGimage);
                Canvas.SetTop(BGimage, 0);
                Canvas.SetLeft(BGimage, 0);
                BG_Prev.Source = BGimage.Source;
               

            }
            
            
        }
        private void ClearBG_Click(object sender, RoutedEventArgs e)
        {

            Image BGimage = new Image
            {
                Width = SketchSurface.ActualWidth,
                Height = SketchSurface.ActualHeight,
                Stretch = Stretch.Fill,
                Source = new BitmapImage(new Uri(@"pack://application:,,,/SunshineSketch;component/Images/WHITE.png"))
            };
            Canvas canvas = new Canvas { Width = SketchSurface.ActualWidth, Height = SketchSurface.ActualHeight };
            SketchSurface.Children.Add(canvas);
            canvas.Children.Add(BGimage);
            Canvas.SetTop(BGimage, 0);
            Canvas.SetLeft(BGimage, 0);
            BG_Prev.Source = BGimage.Source;

        }

        public void SaveAsPNG(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.SaveFileDialog SavePNG = new Microsoft.Win32.SaveFileDialog();
            SavePNG.FileName = ""; // Default file name
            SavePNG.DefaultExt = ""; // Default file extension
            SavePNG.Filter = "Portable Network Graphics (.png)|*.png"; // Filter files by extension

            // Show save file dialog box
            Nullable<bool> result = SavePNG.ShowDialog();

            // Process save file dialog box results
            if (result == true)
            {
                // Save document
                string filename = SavePNG.FileName;

                Size size = new Size(SketchSurface.Width,SketchSurface.Height);
                SketchSurface.Measure(size);
                RenderTargetBitmap rtb = new RenderTargetBitmap((int)size.Width, (int)size.Height, 96, 96, PixelFormats.Pbgra32);

                SketchSurface.Arrange(new Rect(0, 0, SketchSurface.ActualWidth, SketchSurface.ActualHeight  )); // This is important

                
                rtb.Render(SketchSurface);
                PngBitmapEncoder png = new PngBitmapEncoder();
                png.Frames.Add(BitmapFrame.Create(rtb));
                rtb.Render(SketchSurface_mid);
                png.Frames.Add(BitmapFrame.Create(rtb));

                using (Stream stm = File.Create(filename))
                {
                    png.Save(stm);
                    stm.Close();
                }
            

            }

        }

        private void image1_ImageFailed(object sender, ExceptionRoutedEventArgs e)
        {

        }

        
//Palette Colors


        SolidColorBrush PalPreview1 = new SolidColorBrush(Colors.Red);
       
        private void Original20_Click(object sender, MouseButtonEventArgs e)
        {
            Rectangle palchange = (Rectangle)sender;
            String palstg = palchange.Fill.ToString();
            Color palcolor = (Color)ColorConverter.ConvertFromString(palstg);
            SketchSurface.DefaultDrawingAttributes.Color = palcolor;
            ColorL.Fill = palchange.Fill;
            R_Slider.Value = palcolor.R;
            B_Slider.Value = palcolor.B;
            G_Slider.Value = palcolor.G;
        }

        private string ToString(Brush brush)
        {
            throw new NotImplementedException();
        }

        private string ToString(Rectangle palchange)
        {
            throw new NotImplementedException();
        }

 //sketchsurface select and initialization      

        private void SketchSurface_Initialized(object sender, EventArgs e)
        {
            SketchSurface.DefaultDrawingAttributes.Height = 2;
            SketchSurface.DefaultDrawingAttributes.Width = 2;
        }

        private void Back_layer_sel_Checked(object sender, RoutedEventArgs e)
        {
            SketchSurface.IsEnabled = true;
            SketchSurface_mid.IsEnabled = false;
            SketchSurface_mid.IsHitTestVisible = false;
            
            
        }

        private void Mid_layer_sel_Checked(object sender, RoutedEventArgs e)
        {
            SketchSurface.IsEnabled = false;
            SketchSurface_mid.IsEnabled = true;
            SketchSurface_mid.IsHitTestVisible = true;
            
        }

       

        private void ellipse1_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (SketchSurface.DefaultDrawingAttributes.FitToCurve == false)
            {
                SketchSurface.DefaultDrawingAttributes.FitToCurve = true;
                ellipse.Fill = new SolidColorBrush(Colors.Green);

            }
            else
            {
                SketchSurface.DefaultDrawingAttributes.FitToCurve = false;
                ellipse.Fill = new SolidColorBrush(Colors.White);
            }
           
            

        }


        private void BG_RSlider_Val(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            UpdateBGPrev();
        }

        private void BG_GSlider_Val(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            UpdateBGPrev();
        }

        private void BG_BSlider_Val(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            UpdateBGPrev();
        }

        private void Trans_BSlider_Val(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            UpdateBGPrev();
        }

        private void UpdateBGPrev()
        {

            Color BGclr = Color.FromArgb(Convert.ToByte(Trans_Slider.Value), Convert.ToByte(R_Slider.Value),

            Convert.ToByte(G_Slider.Value), Convert.ToByte(B_Slider.Value));

             SketchSurface.DefaultDrawingAttributes.Color = BGclr;
             ColorL.Fill = new SolidColorBrush(BGclr);
            //RedValue.Text = BG_RSlider.Value.ToString();
            //GreenValue.Text = BG_BSlider.Value.ToString();
            //BlueValue.Text = BG_GSlider.Value.ToString();


        }


        public SolidColorBrush SketchCanvas { get; set; }

        private void SvColor_Click(object sender, RoutedEventArgs e)
        {
            SolidColorBrush NewFill = new SolidColorBrush(SketchSurface.DefaultDrawingAttributes.Color);
            
            if (Custom_slot01.Fill == null)
            {

                
                Custom_slot01.Fill = NewFill;
            }
            else if (Custom_slot02.Fill == null)
            {

                
                Custom_slot02.Fill = NewFill;
            }
            else if (Custom_slot03.Fill == null)
            {


                Custom_slot03.Fill = NewFill;
            }
            else if (Custom_slot04.Fill == null)
            {


                Custom_slot04.Fill = NewFill;
            }
            else if (Custom_slot05.Fill == null)
            {


                Custom_slot05.Fill = NewFill;
            }
            else if (Custom_slot06.Fill == null)
            {


                Custom_slot06.Fill = NewFill;
            }
            else if (Custom_slot07.Fill == null)
            {


                Custom_slot07.Fill = NewFill;
            }
            else if (Custom_slot08.Fill == null)
            {


                Custom_slot08.Fill = NewFill;
            }
            else if (Custom_slot09.Fill == null)
            {


                Custom_slot09.Fill = NewFill;
            }
            else if (Custom_slot10.Fill == null)
            {


                Custom_slot10.Fill = NewFill;
            }

            else if (Custom_slot11.Fill == null)
            {


                Custom_slot11.Fill = NewFill;
            }
            else if (Custom_slot12.Fill == null)
            {


                Custom_slot12.Fill = NewFill;
            }
            else if (Custom_slot13.Fill == null)
            {


                Custom_slot13.Fill = NewFill;
            }
            else if (Custom_slot14.Fill == null)
            {


                Custom_slot14.Fill = NewFill;
            }
            else if (Custom_slot15.Fill == null)
            {


                Custom_slot15.Fill = NewFill;
            }
            else if (Custom_slot16.Fill == null)
            {


                Custom_slot16.Fill = NewFill;
            }
            else if (Custom_slot17.Fill == null)
            {


                Custom_slot17.Fill = NewFill;
            }
            else if (Custom_slot18.Fill == null)
            {


                Custom_slot18.Fill = NewFill;
            }
            else if (Custom_slot19.Fill == null)
            {


                Custom_slot19.Fill = NewFill;
            }
            else if (Custom_slot20.Fill == null)
            {


                Custom_slot20.Fill = NewFill;
            }
            else if (Custom_slot21.Fill == null)
            {


                Custom_slot21.Fill = NewFill;
            }
            else if (Custom_slot22.Fill == null)
            {


                Custom_slot22.Fill = NewFill;
            }
            else if (Custom_slot23.Fill == null)
            {


                Custom_slot23.Fill = NewFill;
            }
            else if (Custom_slot24.Fill == null)
            {


                Custom_slot24.Fill = NewFill;
            }
            else
            {
                MessageBox.Show("Palette is Full!", "Notice", MessageBoxButton.OK, MessageBoxImage.Asterisk);
            }


         
        }

        private void Custom_slot_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Rectangle mod = (Rectangle)sender;
            Color Pix = Colors.Gray;
                Pix = (mod.Fill as SolidColorBrush).Color;
                SketchSurface.DefaultDrawingAttributes.Color = Pix;
                ColorL.Fill = mod.Fill;
            
        }

        // deleting slots

        private void Custom_slot_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {

            Rectangle mod = (Rectangle)sender;
            mod.Fill = null;

        }

   
//Save palette
        private void Sv_Palette_button_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.SaveFileDialog SavePal= new Microsoft.Win32.SaveFileDialog();
            SavePal.FileName = ""; // Default file name
            SavePal.DefaultExt = ""; // Default file extension
            SavePal.Filter = "Sunshine Sketch Palette (.ssp)|*.ssp"; // Filter files by extension

            // Show save file dialog box
            Nullable<bool> result = SavePal.ShowDialog();

            // Process save file dialog box results
            if (result == true)
            {
                // Save document
                string filename = SavePal.FileName;
                using (StreamWriter sw = new StreamWriter(SavePal.FileName))
                {
                    sw.WriteLine(Custom_slot01.Fill);
                    sw.WriteLine(Custom_slot02.Fill);
                    sw.WriteLine(Custom_slot03.Fill);
                    sw.WriteLine(Custom_slot04.Fill);
                    sw.WriteLine(Custom_slot05.Fill);
                    sw.WriteLine(Custom_slot06.Fill);
                    sw.WriteLine(Custom_slot07.Fill);
                    sw.WriteLine(Custom_slot08.Fill);
                    sw.WriteLine(Custom_slot09.Fill);
                    sw.WriteLine(Custom_slot10.Fill);
                    sw.WriteLine(Custom_slot11.Fill);
                    sw.WriteLine(Custom_slot12.Fill);
                    sw.WriteLine(Custom_slot13.Fill);
                    sw.WriteLine(Custom_slot14.Fill);
                    sw.WriteLine(Custom_slot15.Fill);
                    sw.WriteLine(Custom_slot16.Fill);
                    sw.WriteLine(Custom_slot17.Fill);
                    sw.WriteLine(Custom_slot18.Fill);
                    sw.WriteLine(Custom_slot19.Fill);
                    sw.WriteLine(Custom_slot20.Fill);
                    sw.WriteLine(Custom_slot21.Fill);
                    sw.WriteLine(Custom_slot22.Fill);
                    sw.WriteLine(Custom_slot23.Fill);
                    sw.WriteLine(Custom_slot24.Fill);
                }
                
                
            }

        }

        private object SolidColorBrush(Brush brush)
        {
            throw new NotImplementedException();
        }


//Load palette

        private void LoadPalette_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog OpenPal = new Microsoft.Win32.OpenFileDialog();
            OpenPal.FileName = ""; // Default file name
            OpenPal.DefaultExt = ""; // Default file extension
            OpenPal.Filter = "Sunshine Sketch Palette (.ssp)|*.ssp"; // Filter files by extension
            // Show save file dialog box
            Nullable<bool> result = OpenPal.ShowDialog();

            // Process Open file dialog box results
            if (result == true)
            {
                using (StreamReader sr = new StreamReader(OpenPal.FileName))
                {

                    int i = 1;
                    String convtobrush;
                    
                    for (i = 1; i < 24; i++)
                    {
                        convtobrush = sr.ReadLine();
                        if (convtobrush.Length == 0)
                        {
                            break;
                        }
                        var converter = new System.Windows.Media.BrushConverter();
                        var brush = (Brush)converter.ConvertFromString(convtobrush);
                        switch (i)
                        {
                            case 0:
                                //do nothing
                                break;
                            case 1:  Custom_slot01.Fill = brush;
                                break;
                            case 2: Custom_slot02.Fill = brush;
                                break;
                            case 3: Custom_slot03.Fill = brush;
                                break;
                            case 4: Custom_slot04.Fill = brush;
                                break;
                            case 5: Custom_slot05.Fill = brush;
                                break;
                            case 6: Custom_slot06.Fill = brush;
                                break;
                            case 7: Custom_slot07.Fill = brush;
                                break;
                            case 8: Custom_slot08.Fill = brush;
                                break;
                            case 9: Custom_slot09.Fill = brush;
                                break;
                            case 10: Custom_slot10.Fill = brush;
                                break;
                            case 11: Custom_slot11.Fill = brush;
                                break;
                            case 12: Custom_slot12.Fill = brush;
                                break;
                            case 13: Custom_slot13.Fill = brush;
                                break;
                            case 14: Custom_slot14.Fill = brush;
                                break;
                            case 15: Custom_slot15.Fill = brush;
                                break;
                            case 16: Custom_slot16.Fill = brush;
                                break;
                            case 17: Custom_slot17.Fill = brush;
                                break;
                            case 18: Custom_slot18.Fill = brush;
                                break;
                            case 19: Custom_slot19.Fill = brush;
                                break;
                            case 20: Custom_slot20.Fill = brush;
                                break;
                            case 21: Custom_slot21.Fill = brush;
                                break;
                            case 22: Custom_slot22.Fill = brush;
                                break;
                            case 23: Custom_slot23.Fill = brush;
                                break;
                            case 24: Custom_slot24.Fill = brush;
                                break;
                           
                        }
                    }
                }

            }

        }

        private void NewSketch(object sender, RoutedEventArgs e)
        {
            if ((SketchSurface.Strokes.Count > 0) || (SketchSurface_mid.Strokes.Count > 0))
            {
                string messageBoxText = "Do you wish to save changes to the current sketch?";
                string caption = "Unsaved Changes";
                MessageBoxButton button = MessageBoxButton.YesNoCancel;
                MessageBoxImage icon = MessageBoxImage.Warning;
                MessageBoxResult result = MessageBox.Show(messageBoxText, caption, button, icon);
                
                switch (result)
                {
                    case MessageBoxResult.Yes:
                        
                        this.Fil_ss.RaiseEvent(new RoutedEventArgs(MenuItem.ClickEvent));
                        SketchSurface.Strokes.Clear();
                        SketchSurface_mid.Strokes.Clear();
                            //clear bg
                            Image BGimage = new Image
                            {
                                Width = SketchSurface.ActualWidth,
                                Height = SketchSurface.ActualHeight,
                                Stretch = Stretch.Fill,
                                Source = new BitmapImage(new Uri(@"pack://application:,,,/SunshineSketch;component/Images/WHITE.png"))
                            };
                            Canvas canvas = new Canvas { Width = SketchSurface.ActualWidth, Height = SketchSurface.ActualHeight };
                            SketchSurface.Children.Add(canvas);
                            canvas.Children.Add(BGimage);
                            Canvas.SetTop(BGimage, 0);
                            Canvas.SetLeft(BGimage, 0);
                            BG_Prev.Source = BGimage.Source;
                            //bg cleared
                        FileOpened.Content = "New (Unsaved)";
                        break;
                    case MessageBoxResult.No:
                        SketchSurface.Strokes.Clear();
                        SketchSurface_mid.Strokes.Clear();
                            //clear bg
                            BGimage = new Image
                            {
                                Width = SketchSurface.ActualWidth,
                                Height = SketchSurface.ActualHeight,
                                Stretch = Stretch.Fill,
                                Source = new BitmapImage(new Uri(@"pack://application:,,,/SunshineSketch;component/Images/WHITE.png"))
                            };
                            canvas = new Canvas { Width = SketchSurface.ActualWidth, Height = SketchSurface.ActualHeight };
                            SketchSurface.Children.Add(canvas);
                            canvas.Children.Add(BGimage);
                            Canvas.SetTop(BGimage, 0);
                            Canvas.SetLeft(BGimage, 0);
                            BG_Prev.Source = BGimage.Source;
                            //bg cleared
                        FileOpened.Content = "New (Unsaved)";
                        break;
                    case MessageBoxResult.Cancel:
                        //Do nothing
                        break;

                }
            }
            else
            {
                SketchSurface.Strokes.Clear();
                SketchSurface_mid.Strokes.Clear();
                FileOpened.Content = "New (Unsaved)";
                
                //clear bg
                Image BGimage = new Image
                {
                    Width = SketchSurface.ActualWidth,
                    Height = SketchSurface.ActualHeight,
                    Stretch = Stretch.Fill,
                    Source = new BitmapImage(new Uri(@"pack://application:,,,/SunshineSketch;component/Images/WHITE.png"))
                };
                Canvas canvas = new Canvas { Width = SketchSurface.ActualWidth, Height = SketchSurface.ActualHeight };
                SketchSurface.Children.Add(canvas);
                canvas.Children.Add(BGimage);
                Canvas.SetTop(BGimage, 0);
                Canvas.SetLeft(BGimage, 0);
                BG_Prev.Source = BGimage.Source;
                //bg cleared
            }
           

        }

        private void RC_Tool(object sender, MouseButtonEventArgs e)
        {
            
            Rectangle Option = (Rectangle)sender;
            SolidColorBrush grn = new SolidColorBrush(Colors.LightGreen);
            SolidColorBrush blk = new SolidColorBrush(Colors.Black);
            //disables all options for a few cycles, then enables selected one.
            RapidUndo.Stroke = blk; RapidUndo.StrokeThickness = 1;
            Eyedrop.Stroke = blk; Eyedrop.StrokeThickness = 1;
            ellipse_sel.Stroke = blk; ellipse_sel.StrokeThickness = 1;
            line_sel.Stroke = blk; line_sel.StrokeThickness = 1;
            thebendz.Stroke = blk; thebendz.StrokeThickness = 1;
            ellescaleY.IsEnabled = false;
            elleshapeX.IsEnabled = false;
            Option.Stroke = grn;
            Option.StrokeThickness = 1.5;
            

            if (Option.Name.Equals("ellipse_sel"))
            {
                ellescaleY.IsEnabled = true;
                elleshapeX.IsEnabled = true;
            }
       
          
        }

        public StylusPointCollection line = new StylusPointCollection();
        public StylusPointCollection bend = new StylusPointCollection();

        private void UseRightTool(object sender, MouseButtonEventArgs e)
        {

            if (Eyedrop.StrokeThickness.Equals(1.5) == true)
            {

                Point mouseloc = Mouse.GetPosition(SketchSurface);
                StrokeCollection sapcolor;
                if (Back_layer_sel.IsChecked == true)
                {
                    sapcolor = SketchSurface.Strokes.HitTest(mouseloc, 2);

                }
                else
                {
                    sapcolor = SketchSurface_mid.Strokes.HitTest(mouseloc, 2);
                }
                
                Stroke slice;

                if (sapcolor.Count.Equals(0))
                {
                    //do nothing.

                    
                }
                else
                {
                    slice = sapcolor.Last();
                    Color palcolor = slice.DrawingAttributes.Color;
                    SolidColorBrush palchange = new SolidColorBrush(palcolor);
                    SketchSurface.DefaultDrawingAttributes.Color = palcolor;
                    ColorL.Fill = palchange;
                    R_Slider.Value = palcolor.R;
                    B_Slider.Value = palcolor.B;
                    G_Slider.Value = palcolor.G;
                    Trans_Slider.Value = palcolor.A;
                    
                    
                }

        
            }

            if (RapidUndo.StrokeThickness.Equals(1.5) == true)
            {
                
                if (Back_layer_sel.IsChecked == true)
                {
                    try
                    {
                        SketchSurface.Strokes.Remove(SketchSurface.Strokes.Last());
                    }
                    catch
                    {
                        //do nothing
                    }
                }
                else
                {
                    try
                    {
                        SketchSurface_mid.Strokes.Remove(SketchSurface_mid.Strokes.Last());
                    }
                    catch
                    {
                        //do nothing
                    }
                }

            }


            if (ellipse_sel.StrokeThickness.Equals(1.5))
            {
                double xmult = 1;
                double ymult = 1;
                try
                {
                    xmult = Convert.ToDouble(elleshapeX.Text);
                }
                catch
                {
                    elleshapeX.Text = "1.0";
                    xmult = 1.0;
                }
                try
                {
                    ymult = Convert.ToDouble(ellescaleY.Text);
                }
                catch
                {
                    ellescaleY.Text = "1.0";
                    ymult = 1.0;
                }
               
                //Ellipse calulation!
                Point mouseloc = Mouse.GetPosition(SketchSurface);
                StylusPointCollection elle = new StylusPointCollection();
                // topleft
                elle.Add(new StylusPoint(mouseloc.X - (0 * xmult), mouseloc.Y + (0 * ymult)));
                elle.Add(new StylusPoint(mouseloc.X - (16 * xmult), mouseloc.Y + (3 * ymult)));
                elle.Add(new StylusPoint(mouseloc.X - (32 * xmult), mouseloc.Y + (6 * ymult)));
                elle.Add(new StylusPoint(mouseloc.X - (48 * xmult), mouseloc.Y + (11 * ymult)));
                elle.Add(new StylusPoint(mouseloc.X - (64 * xmult), mouseloc.Y + (20 * ymult)));
                elle.Add(new StylusPoint(mouseloc.X - (80 * xmult), mouseloc.Y + (33 * ymult)));
                elle.Add(new StylusPoint(mouseloc.X - (96 * xmult), mouseloc.Y + (52 * ymult)));
                elle.Add(new StylusPoint(mouseloc.X - (128 * xmult), mouseloc.Y + (110 * ymult)));
               
                elle.Add(new StylusPoint(mouseloc.X - (128 * xmult), mouseloc.Y + (126 * ymult)));
               
                // bottomleft
                elle.Add(new StylusPoint(mouseloc.X - (128 * xmult), mouseloc.Y + (142 * ymult)));
                elle.Add(new StylusPoint(mouseloc.X - (96 * xmult), mouseloc.Y + (200 * ymult)));
                elle.Add(new StylusPoint(mouseloc.X - (80 * xmult), mouseloc.Y + (219 * ymult)));
                elle.Add(new StylusPoint(mouseloc.X - (64 * xmult), mouseloc.Y + (234 * ymult)));
                elle.Add(new StylusPoint(mouseloc.X - (48 * xmult), mouseloc.Y + (243 * ymult)));
                elle.Add(new StylusPoint(mouseloc.X - (32 * xmult), mouseloc.Y + (250 * ymult)));
                elle.Add(new StylusPoint(mouseloc.X - (16 * xmult), mouseloc.Y + (253 * ymult)));
                elle.Add(new StylusPoint(mouseloc.X - (0 * xmult), mouseloc.Y + (256 * ymult)));

                elle.Add(new StylusPoint(mouseloc.X + (16 * xmult), mouseloc.Y + (256 * ymult)));
                // bottomright
                elle.Add(new StylusPoint(mouseloc.X + (16 * xmult), mouseloc.Y + (256 * ymult)));
                elle.Add(new StylusPoint(mouseloc.X + (32 * xmult), mouseloc.Y + (253 * ymult)));
                elle.Add(new StylusPoint(mouseloc.X + (48 * xmult), mouseloc.Y + (250 * ymult)));
                elle.Add(new StylusPoint(mouseloc.X + (64 * xmult), mouseloc.Y + (243 * ymult)));
                elle.Add(new StylusPoint(mouseloc.X + (80 * xmult), mouseloc.Y + (234 * ymult)));
                elle.Add(new StylusPoint(mouseloc.X + (96 * xmult), mouseloc.Y + (219 * ymult)));
                elle.Add(new StylusPoint(mouseloc.X + (128 * xmult), mouseloc.Y + (200 * ymult)));
                elle.Add(new StylusPoint(mouseloc.X + (144 * xmult), mouseloc.Y + (142 * ymult)));

                elle.Add(new StylusPoint(mouseloc.X + (144 * xmult), mouseloc.Y + (126 * ymult)));
                //topright
                elle.Add(new StylusPoint(mouseloc.X + (144 * xmult), mouseloc.Y + (110 * ymult)));
                elle.Add(new StylusPoint(mouseloc.X + (128 * xmult), mouseloc.Y + (52 * ymult)));
                elle.Add(new StylusPoint(mouseloc.X + (96 * xmult), mouseloc.Y + (33 * ymult)));
                elle.Add(new StylusPoint(mouseloc.X + (80 * xmult), mouseloc.Y + (20 * ymult)));
                elle.Add(new StylusPoint(mouseloc.X + (64 * xmult), mouseloc.Y + (11 * ymult)));
                elle.Add(new StylusPoint(mouseloc.X + (48 * xmult), mouseloc.Y + (6 * ymult)));
                elle.Add(new StylusPoint(mouseloc.X + (32 * xmult), mouseloc.Y + (3 * ymult)));
                elle.Add(new StylusPoint(mouseloc.X + (16 * xmult), mouseloc.Y + (0 * ymult)));
                elle.Add(new StylusPoint(mouseloc.X + (0 * xmult), mouseloc.Y + (0 * ymult)));
                
                // Make ellipse!
                Stroke printelle = new Stroke(elle);
                printelle.DrawingAttributes.FitToCurve = true;
                printelle.DrawingAttributes.Width = SketchSurface.DefaultDrawingAttributes.Width;
                printelle.DrawingAttributes.Height = SketchSurface.DefaultDrawingAttributes.Height;
                printelle.DrawingAttributes.Color = SketchSurface.DefaultDrawingAttributes.Color;
                if (Back_layer_sel.IsChecked.Equals(true))
                {
                    SketchSurface.Strokes.Add(printelle);
                }
                else if (Middle_layer_sel.IsChecked.Equals(true))
                {
                    
                    SketchSurface_mid.Strokes.Add(printelle);
                }

            }

            if (line_sel.StrokeThickness.Equals(1.5))
            {
                if (line.Count.Equals(1) || line.Count.Equals(0))
                {
                    Point mouseloc = Mouse.GetPosition(SketchSurface);
                    line.Add(new StylusPoint(mouseloc.X, mouseloc.Y));
                }
                if (line.Count.Equals(2))
                {
                    Stroke linemake = new Stroke(line);
                    linemake.DrawingAttributes.FitToCurve = SketchSurface.DefaultDrawingAttributes.FitToCurve;
                    linemake.DrawingAttributes.Color = SketchSurface.DefaultDrawingAttributes.Color;
                    linemake.DrawingAttributes.Width = SketchSurface.DefaultDrawingAttributes.Width;
                    linemake.DrawingAttributes.Height = SketchSurface.DefaultDrawingAttributes.Height;
                    if (Back_layer_sel.IsChecked.Equals(true))
                    {
                        SketchSurface.Strokes.Add(linemake);
                    }
                    else if (Middle_layer_sel.IsChecked.Equals(true))
                    {

                        SketchSurface_mid.Strokes.Add(linemake);
                    }
                   
                    line = new StylusPointCollection();
                
                }
                 
            }
            if (thebendz.StrokeThickness.Equals(1.5))
            {
                if (bend.Count.Equals(2) || bend.Count.Equals(1) || bend.Count.Equals(0))
                {
                    Point mouseloc = Mouse.GetPosition(SketchSurface);
                    bend.Add(new StylusPoint(mouseloc.X, mouseloc.Y));
                }
                if (bend.Count.Equals(3))
                {
                    Stroke linemake = new Stroke(bend);
                    linemake.DrawingAttributes.FitToCurve = true;
                    linemake.DrawingAttributes.Color = SketchSurface.DefaultDrawingAttributes.Color;
                    linemake.DrawingAttributes.Width = SketchSurface.DefaultDrawingAttributes.Width;
                    linemake.DrawingAttributes.Height = SketchSurface.DefaultDrawingAttributes.Height;
                    if (Back_layer_sel.IsChecked.Equals(true))
                    {
                        SketchSurface.Strokes.Add(linemake);
                    }
                    else if (Middle_layer_sel.IsChecked.Equals(true))
                    {

                        SketchSurface_mid.Strokes.Add(linemake);
                    }
                    bend = new StylusPointCollection();

                }


            }
        }



        private void BrushSizeSel(object sender, MouseButtonEventArgs e)
        {
            Rectangle picked = (Rectangle)sender;
            SolidColorBrush grn = new SolidColorBrush(Colors.LightGreen);
            SolidColorBrush blk = new SolidColorBrush(Colors.Black);
            tallbrush.StrokeThickness = 1; tallbrush.Stroke = blk;
            smallbrush.StrokeThickness = 1; smallbrush.Stroke = blk;
            medbrushtall.StrokeThickness = 1; medbrushtall.Stroke = blk;
            medbrushwide.StrokeThickness = 1; medbrushwide.Stroke = blk;
            picked.StrokeThickness = 1.5;
            picked.Stroke = grn;

            if (smallbrush.StrokeThickness.Equals(1.5) == true)
            {
                SketchSurface.DefaultDrawingAttributes.Width = 3;
                SketchSurface.DefaultDrawingAttributes.Height = 3;

            }
            if (medbrushtall.StrokeThickness.Equals(1.5) == true)
            {
                SketchSurface.DefaultDrawingAttributes.Width = 3;
                SketchSurface.DefaultDrawingAttributes.Height = 5;

            }
            if (medbrushwide.StrokeThickness.Equals(1.5) == true)
            {
                SketchSurface.DefaultDrawingAttributes.Width = 5;
                SketchSurface.DefaultDrawingAttributes.Height = 3;

            }
            if (tallbrush.StrokeThickness.Equals(1.5) == true)
            {
                SketchSurface.DefaultDrawingAttributes.Width = 4;
                SketchSurface.DefaultDrawingAttributes.Height = 8;

            }
             if (Eraser.StrokeThickness.Equals(1.5) == true)
            {
                if (SketchSurface.EditingMode.Equals(InkCanvasEditingMode.Ink))
                {
                    Eraser.Stroke = new SolidColorBrush(Colors.Red);
                    SketchSurface.EditingMode = InkCanvasEditingMode.EraseByPoint;
                    SketchSurface.EraserShape = new EllipseStylusShape(SketchSurface.DefaultDrawingAttributes.Width,
                        SketchSurface.DefaultDrawingAttributes.Height);
                    SketchSurface_mid.EditingMode = InkCanvasEditingMode.EraseByPoint;
                    SketchSurface_mid.EraserShape = new EllipseStylusShape(SketchSurface.DefaultDrawingAttributes.Width,
                        SketchSurface.DefaultDrawingAttributes.Height);
                }
                else
                { 
                    SketchSurface.EditingMode = InkCanvasEditingMode.Ink;
                    SketchSurface_mid.EditingMode = InkCanvasEditingMode.Ink;
                    Eraser.StrokeThickness = 1; Eraser.Stroke = blk;
                    
                }
            }
   
         }

        private void UpdateEraser(object sender, TextCompositionEventArgs e)
        {
            SketchSurface.EraserShape = new EllipseStylusShape(SketchSurface.DefaultDrawingAttributes.Width,
                       SketchSurface.DefaultDrawingAttributes.Height);
            SketchSurface_mid.EraserShape = new EllipseStylusShape(SketchSurface.DefaultDrawingAttributes.Width,
                       SketchSurface.DefaultDrawingAttributes.Height);
        }

      

        private void Sketchsave(object sender, RoutedEventArgs e)
        {
            
            SketchSurface.Strokes.AddPropertyData(wd, SketchSurface.Width);
            SketchSurface.Strokes.AddPropertyData(ht, SketchSurface.Height);
            string filename = FileOpened.Content.ToString();
            string do_open = "New (Unsaved)";
            if (filename.Contains(do_open))
            {
                Microsoft.Win32.SaveFileDialog SaveS = new Microsoft.Win32.SaveFileDialog();
                SaveS.FileName = ""; // Default file name
                SaveS.DefaultExt = ""; // Default file extension
                SaveS.Filter = "Sunshine Sketch (.ssf)|*.ssf"; // Filter files by extension

                // Show save file dialog box
                Nullable<bool> result = SaveS.ShowDialog();

                // Process save file dialog box results
                if (result == true)
                {
                    // Save document
                    using (FileStream fs = new FileStream(filename, FileMode.Create))
                    {
                        SketchSurface.Strokes.Save(fs);
                        SketchSurface_mid.Strokes.Save(fs);
                        fs.Close();
                    };
                
                    FileOpened.Content = SaveS.FileName;
                }
            }
            else
            {
                
                using (FileStream fs = new FileStream(filename, FileMode.Create))
                {
                    SketchSurface.Strokes.Save(fs);
                    SketchSurface_mid.Strokes.Save(fs);
                    fs.Close();
                };

               

            }
        }

        private void Sketchopen(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog Openstay = new Microsoft.Win32.OpenFileDialog();
            Openstay.FileName = ""; // Default file name
            Openstay.DefaultExt = ""; // Default file extension
            Openstay.Filter = "Sunshine Sketch (.ssf)|*.ssf"; // Filter files by extension

            // Show save file dialog box
            Nullable<bool> result = Openstay.ShowDialog();

            // Process save file dialog box results
            if (result == true)
            {
                // Open document
                string filename = Openstay.FileName;
                using (FileStream fs = new FileStream(Openstay.FileName, FileMode.Open))
                {
                    SketchSurface.Strokes = new StrokeCollection(fs);
                    SketchSurface_mid.Strokes = new StrokeCollection(fs);
                    try
                    {
                        SketchSurface.Strokes.GetPropertyData(wd);
                    }
                    catch
                    {
                        //do nothing
                    }
                    try
                    {
                    SketchSurface.Strokes.GetPropertyData(ht);
                    }
                    catch
                    {
                        //do nothing
                    }
                    try
                    {
                        SketchSurface.Strokes.GetPropertyData(bg);
                    }
                    catch
                    {
                        //do nothing
                    }
                        fs.Close();
                };

                try
                {
                SketchSurface.Width = Convert.ToDouble(SketchSurface.Strokes.GetPropertyData(wd));
                }
                catch
                {
                    //do nothing
                }
                try
                {
                    SketchSurface.Height = Convert.ToDouble(SketchSurface.Strokes.GetPropertyData(ht));
                }
                catch
                {
                    //do nothing
                }
                FileOpened.Content = Openstay.FileName;
            }
        }

    
        private void scrollViewer1_MouseMove(object sender, MouseEventArgs e)
        {
            Point dd = Mouse.GetPosition(SketchSurface);
            Xpos.Content = dd.X.ToString();
            Ypos.Content = dd.Y.ToString();

        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            var set = new SS_Settings();
            set.Show();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

        }




   
    }


}


